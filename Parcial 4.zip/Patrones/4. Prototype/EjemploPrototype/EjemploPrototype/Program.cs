﻿using System;

namespace EjemploPrototype
{

	class MainClass
	{
		static void Main(string[] args)
		{
			Developer dev = new Developer();
			dev.Name = "Rahul";
			dev.Role = "Team Leader";
			dev.PreferredLanguage = "C#";

			Developer devCopy = (Developer)dev.Clone();
			devCopy.Name = "Arif"; 

			Console.WriteLine(dev.GetDetails());
			Console.WriteLine(devCopy.GetDetails());

			Typist typist = new Typist();
			typist.Name = "Monu";
			typist.Role = "Typist";
			typist.WordsPerMinute = 120;

			Typist typistCopy = (Typist)typist.Clone();
			typistCopy.Name = "Sahil";
			typistCopy.WordsPerMinute = 115;

			Console.WriteLine(typist.GetDetails());
			Console.WriteLine(typistCopy.GetDetails());

			Console.ReadKey();

		}
	}
	public interface IEmployee
	{
		IEmployee Clone();
		string GetDetails();
	}


	public class Developer : IEmployee
	{
		public int WordsPerMinute { get; set; }
		public string Name { get; set; }
		public string Role { get; set; }
		public string PreferredLanguage { get; set; }

		public IEmployee Clone()
		{
			
			return (IEmployee)MemberwiseClone();


		}

		public string GetDetails()
		{
			return string.Format("{0} - {1} - {2}", Name, Role, PreferredLanguage);
		}
	}


	public class Typist : IEmployee
	{
		public int WordsPerMinute { get; set; }
		public string Name { get; set; }
		public string Role { get; set; }

		public IEmployee Clone()
		{
			
			return (IEmployee)MemberwiseClone();


		}

		public string GetDetails()
		{
			return string.Format("{0} - {1} - {2}wpm", Name, Role, WordsPerMinute);
		}
	}




}
