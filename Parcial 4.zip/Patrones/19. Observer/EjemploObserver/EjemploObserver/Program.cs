﻿using System;
using System.Collections.Generic;
using System.Collections;

namespace EjemploObserver
{
	class MainClass
	{
		
		static void Main()
		{
			
			EventReceiver receiver = new EventReceiver();
			EventMonitor emailer = new EventEmailer(receiver);
			receiver.Attach(emailer);
			EventMonitor logger = new EventLogger(receiver);
			receiver.Attach(logger);

			receiver.LogMessage("Message with two observers.");


			Console.ReadKey();
		}
	}


	public abstract class EventReceiverBase
	{
		private ArrayList _monitors = new ArrayList();

		public void Attach(EventMonitor monitor)
		{
			_monitors.Add(monitor);
		}

		public void Detach(EventMonitor monitor)
		{
			_monitors.Remove(_monitors);
		}

		public void Notify()
		{
			foreach (EventMonitor monitor in _monitors)
			{
				monitor.Update();
			}
		}
	}


	public class EventReceiver : EventReceiverBase
	{
		private string _lastMessage;

		public string GetLastMessage()
		{
			return _lastMessage;
		}

		public void LogMessage(string message)
		{
			_lastMessage = message;
			Notify();
		}
	}


	public abstract class EventMonitor
	{
		public abstract void Update();
	}


	public class EventEmailer : EventMonitor
	{
		private EventReceiver _receiver;

		public EventEmailer(EventReceiver receiver)
		{
			_receiver = receiver;
		}

		public override void Update()
		{
			string message = _receiver.GetLastMessage();
			Console.WriteLine("Emailing: {0}", message);
		}
	}


	public class EventLogger : EventMonitor
	{
		private EventReceiver _receiver;

		public EventLogger(EventReceiver receiver)
		{
			_receiver = receiver;
		}

		public override void Update()
		{
			string message = _receiver.GetLastMessage();
			Console.WriteLine("Logging: {0}", message);
		}
	}
}
