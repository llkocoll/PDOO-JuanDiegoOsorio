﻿using System;
using System.Collections.Generic;

namespace EjemploFactoryMethod
{
	class MainClass
	{
		
		static void Main()
		{
			
			Instrument[] instruments = new Instrument[2];

			instruments[0] = new Chordophone();
			instruments[1] = new Aerophone();

		
			foreach (Instrument instrument in instruments)
			{
				Console.WriteLine("\n" + instrument.GetType().Name + "--");
				foreach (Ins page in instrument.Ins)
				{
					Console.WriteLine(" " + page.GetType().Name);
				}
			}

		
			Console.ReadKey();
		}
	}


	abstract class Ins
	{
	}


	class Guitar : Ins
	{
	}


	class Violin : Ins
	{
	}


	class Piano : Ins
	{
	}


	class Flute : Ins
	{
	}


	class Trumpet : Ins
	{
	}


	class Clarinet : Ins
	{
	}





	abstract class Instrument
	{
		private List<Ins> _ins = new List<Ins>();


		public Instrument()
		{
			this.CreateIns();
		}

		public List<Ins> Ins
		{
			get { return _ins; }
		}


		public abstract void CreateIns();
	}


	class Chordophone : Instrument
	{
		
		public override void CreateIns()
		{
			Ins.Add(new Guitar());
			Ins.Add(new Violin());
			Ins.Add(new Piano());
		}
	}


	class Aerophone : Instrument
	{
		
		public override void CreateIns()
		{
			Ins.Add(new Flute());
			Ins.Add(new Trumpet());
			Ins.Add(new Clarinet());

		}
	}


}
