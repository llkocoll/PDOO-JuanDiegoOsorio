﻿using System;

namespace EjemploTemplateMethod
{
	class MainClass
	{
		
		static void Main()
		{
			ScoringAlgorithm algorithm;

			Console.Write("Man score is: ");
			algorithm = new MensScoringAlgorithm();
			Console.WriteLine(algorithm.GenerateScore(8, new TimeSpan(0, 1, 31)));

			Console.Write("Woman score is: ");
			algorithm = new WomensScoringAlgorithm();
			Console.WriteLine(algorithm.GenerateScore(9, new TimeSpan(0, 1, 49)));

			Console.Write("Child score is: ");
			algorithm = new ChildrensScoringAlgorithm();
			Console.WriteLine(algorithm.GenerateScore(5, new TimeSpan(0, 3, 2)));
		}
	}


	public abstract class ScoringAlgorithm
	{
		public int GenerateScore(int hits, TimeSpan time)
		{
			int score = CalculateBaseScore(hits);
			int reduction = CalculateReduction(time);
			return CalculateOverallScore(score, reduction);
		}

		public abstract int CalculateBaseScore(int hits);

		public abstract int CalculateReduction(TimeSpan time);

		public abstract int CalculateOverallScore(int score, int reduction);
	}


	public class MensScoringAlgorithm : ScoringAlgorithm
	{
		public override int CalculateBaseScore(int hits)
		{
			return hits * 100;
		}

		public override int CalculateReduction(TimeSpan time)
		{
			return ((int)time.TotalSeconds / 5);
		}

		public override int CalculateOverallScore(int score, int reduction)
		{
			return score - reduction;
		}
	}


	public class WomensScoringAlgorithm : ScoringAlgorithm
	{
		public override int CalculateBaseScore(int hits)
		{
			return hits * 100;
		}

		public override int CalculateReduction(TimeSpan time)
		{
			return ((int)time.TotalSeconds / 4);
		}

		public override int CalculateOverallScore(int score, int reduction)
		{
			return score - reduction;
		}
	}


	public class ChildrensScoringAlgorithm : ScoringAlgorithm
	{
		public override int CalculateBaseScore(int hits)
		{
			return hits * 200;
		}

		public override int CalculateReduction(TimeSpan time)
		{
			return ((int)time.TotalSeconds / 2);
		}

		public override int CalculateOverallScore(int score, int reduction)
		{
			if (score > reduction)
				return score - reduction;
			else
				return 0;
		}
	}
}
