﻿using System;

namespace EjemploState
{
	class MainClass
	{
		
		static void Main()
		{
			
			AudioPlayer player = new AudioPlayer(new StandbyState());
			player.PressPlay();
			player.PressAudioSource();
			player.PressPlay();
			player.PressPlay();
			player.PressAudioSource();
			player.PressPlay();
			player.PressAudioSource();

		
			Console.ReadKey();
		}
	}


	public class AudioPlayer
	{
		private AudioPlayerState _state;

		public AudioPlayer(AudioPlayerState state)
		{
			_state = state;
		}

		public void PressPlay()
		{
			_state.PressPlay(this);
		}

		public void PressAudioSource()
		{
			_state.PressAudioSource(this);
		}

		public AudioPlayerState CurrentState
		{
			get { return _state; }
			set { _state = value; }
		}
	}


	public abstract class AudioPlayerState
	{
		public abstract void PressPlay(AudioPlayer player);

		public abstract void PressAudioSource(AudioPlayer player);
	}


	public class StandbyState : AudioPlayerState
	{
		public StandbyState()
		{
			Console.WriteLine("STANDBY");
		}

		public override void PressPlay(AudioPlayer player)
		{
			Console.WriteLine("Play pressed: No effect");
		}

		public override void PressAudioSource(AudioPlayer player)
		{
			player.CurrentState = new MP3PlayingState();
		}
	}


	public class MP3PlayingState : AudioPlayerState
	{
		public MP3PlayingState()
		{
			Console.WriteLine("MP3 PLAYING");
		}

		public override void PressPlay(AudioPlayer player)
		{
			player.CurrentState = new MP3PausedState();
		}

		public override void PressAudioSource(AudioPlayer player)
		{
			player.CurrentState = new RadioState();
		}
	}


	public class MP3PausedState : AudioPlayerState
	{
		public MP3PausedState()
		{
			Console.WriteLine("MP3 PAUSED");
		}

		public override void PressPlay(AudioPlayer player)
		{
			player.CurrentState = new MP3PlayingState();
		}

		public override void PressAudioSource(AudioPlayer player)
		{
			player.CurrentState = new RadioState();
		}
	}


	public class RadioState : AudioPlayerState
	{
		public RadioState()
		{
			Console.WriteLine("RADIO");
		}

		public override void PressPlay(AudioPlayer player)
		{
			Console.WriteLine("Play pressed: New station selected");
		}

		public override void PressAudioSource(AudioPlayer player)
		{
			player.CurrentState = new StandbyState();
		}
	}
}
