﻿using System;
using System.Collections.Generic;

namespace EjemploVisitor
{
	class MainClass
	{
		static void Main()
		{
			
			Manager bob = new Manager();
			bob.Name = "Daryl";
			bob.MonthlySalary = 6000;

			Manager sue = new Manager();
			sue.Name = "Carol";
			sue.MonthlySalary = 3000;

			Worker jim = new Worker();
			jim.Name = "Maggy";
			jim.MonthlySalary = 4000;

			Worker tom = new Worker();
			tom.Name = "Rick";
			tom.MonthlySalary = 2800;

			Worker mel = new Worker();
			mel.Name = "Sasha";
			mel.MonthlySalary = 2500;

			bob.Subordinates.Add(sue);
			bob.Subordinates.Add(jim);
			sue.Subordinates.Add(tom);
			sue.Subordinates.Add(mel);

			OrganisationalStructure org = new OrganisationalStructure(bob);

			PayrollVisitor payroll = new PayrollVisitor();
			PayriseVisitor payrise = new PayriseVisitor(0.05);

			org.Accept(payroll);
			org.Accept(payrise);
			org.Accept(payroll);

			Console.WriteLine("Total pay increase = {0}.", payrise.TotalIncrease);
		}
	}


	public class OrganisationalStructure
	{
		public EmployeeBase Employee { get; set; }

		public OrganisationalStructure(EmployeeBase firstEmployee)
		{
			Employee = firstEmployee;
		}

		public void Accept(VisitorBase visitor)
		{
			Employee.Accept(visitor);
		}
	}


	public abstract class EmployeeBase
	{
		public abstract void Accept(VisitorBase visitor);

		public string Name { get; set; }

		public double MonthlySalary { get; set; }
	}


	public class Worker : EmployeeBase
	{
		public override void Accept(VisitorBase visitor)
		{
			visitor.Visit(this);
		}
	}


	public class Manager : EmployeeBase
	{
		public Manager()
		{
			Subordinates = new List<EmployeeBase>();
		}

		public List<EmployeeBase> Subordinates { get; private set; }

		public override void Accept(VisitorBase visitor)
		{
			visitor.Visit(this);

			foreach (EmployeeBase subordinate in Subordinates)
			{
				subordinate.Accept(visitor);
			}
		}
	}

	public abstract class VisitorBase
	{
		public abstract void Visit(Worker employee);

		public abstract void Visit(Manager employee);
	}


	public class PayrollVisitor : VisitorBase
	{
		public override void Visit(Worker employee)
		{
			Console.WriteLine("{0} paid {1}.", employee.Name, employee.MonthlySalary);
		}

		public override void Visit(Manager employee)
		{
			Console.WriteLine("{0} paid {1} + Bonus."
				, employee.Name, employee.MonthlySalary);
		}
	}


	public class PayriseVisitor : VisitorBase
	{
		double _multiplier;

		public double TotalIncrease { get; private set; }

		public PayriseVisitor(double multiplier)
		{
			_multiplier = multiplier;
			TotalIncrease = 0;
		}

		public override void Visit(Worker employee)
		{
			double increase = employee.MonthlySalary * _multiplier;
			employee.MonthlySalary += increase;
			TotalIncrease += increase;
			Console.WriteLine("{0} salary increased by {1}.", employee.Name, increase);
		}

		public override void Visit(Manager employee)
		{
			double increase = employee.MonthlySalary * _multiplier;
			employee.MonthlySalary += increase;
			TotalIncrease += increase;
			Console.WriteLine("{0} salary increased by {1}.", employee.Name, increase);
		}
	}


}
