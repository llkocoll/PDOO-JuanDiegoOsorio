﻿using System;

namespace EjemploStrategy
{
	class MainClass
	{
		
		static void Main()
		{
			Scoreboard board = new Scoreboard();

			Console.Write("Man score is: ");
			board.Scoring = new MensScoringAlgorithm();
			board.ShowScore(8, new TimeSpan(0, 1, 31));

			Console.Write("Woman score is: ");
			board.Scoring = new WomensScoringAlgorithm();
			board.ShowScore(9, new TimeSpan(0, 1, 49));

			Console.Write("Child score is: ");
			board.Scoring = new ChildrensScoringAlgorithm();
			board.ShowScore(5, new TimeSpan(0, 3, 2));


			Console.ReadKey();
		}
	}


	public class Scoreboard
	{
		public ScoringAlgorithmBase Scoring { get; set; }

		public void ShowScore(int hits, TimeSpan time)
		{
			Console.WriteLine(Scoring.CalculateScore(hits, time));
		}
	}


	public abstract class ScoringAlgorithmBase
	{
		public abstract int CalculateScore(int hits, TimeSpan time);
	}


	public class MensScoringAlgorithm : ScoringAlgorithmBase
	{
		public override int CalculateScore(int hits, TimeSpan time)
		{
			return (hits * 100) - ((int)time.TotalSeconds / 5);
		}
	}


	public class WomensScoringAlgorithm : ScoringAlgorithmBase
	{
		public override int CalculateScore(int hits, TimeSpan time)
		{
			return (hits * 100) - ((int)time.TotalSeconds / 4);
		}
	}


	public class ChildrensScoringAlgorithm : ScoringAlgorithmBase
	{
		public override int CalculateScore(int hits, TimeSpan time)
		{
			return (hits * 200) - ((int)time.TotalSeconds / 2);
		}
	}
}
