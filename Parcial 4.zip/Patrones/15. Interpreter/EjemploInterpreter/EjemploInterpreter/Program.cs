﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EjemploInterpreter
{
	class MainClass
	{
		static void Main(string[] args)
		{
			string tokenString = "+ - 10 2 3";
			List<string> tokenList = new List<string>(tokenString.Split(' '));

			IExpression expression = new TokenReader().ReadToken(tokenList);
			Console.WriteLine(expression.Interpret());    

			tokenString = "- + 10 5 - 8 2";
			tokenList = new List<string>(tokenString.Split(' '));

			expression = new TokenReader().ReadToken(tokenList);
			Console.WriteLine(expression.Interpret());   
		}
	}

	public interface IExpression
	{
		int Interpret();
	}


	public class NumberExpression : IExpression
	{
		int number;
		public NumberExpression(int i)
		{
			number = i;
		}

		int IExpression.Interpret()
		{
			return number;
		}
	}


	public class AddExpression : IExpression
	{
		IExpression leftExpression;
		IExpression rightExpression;

		public AddExpression(IExpression left, IExpression right)
		{
			leftExpression = left;
			rightExpression = right;
		}

		int IExpression.Interpret()
		{
			return leftExpression.Interpret() + rightExpression.Interpret();
		}
	}


	public class SubtractExpression : IExpression
	{
		IExpression leftExpression;
		IExpression rightExpression;

		public SubtractExpression(IExpression left, IExpression right)
		{
			leftExpression = left;
			rightExpression = right;
		}

		int IExpression.Interpret()
		{
			return leftExpression.Interpret() - rightExpression.Interpret();
		}
	}

	public class TokenReader
	{
		public IExpression ReadToken(List<string> tokenList)
		{
			return ReadNextToken(tokenList);
		}

		private IExpression ReadNextToken(List<string> tokenList)
		{
			int i;
			if (int.TryParse(tokenList.First(), out i))  
			{
				tokenList.RemoveAt(0);
				return new NumberExpression(i);
			}
			else
			{
				return ReadNonTerminal(tokenList); 
			}
		}

		private IExpression ReadNonTerminal(List<string> tokenList)
		{
			string token = tokenList.First();
			tokenList.RemoveAt(0);  
			IExpression left = ReadNextToken(tokenList); 
			IExpression right = ReadNextToken(tokenList); 

			if (token == "+")
				return new AddExpression(left, right);
			else if (token == "-")
				return new SubtractExpression(left, right);
			return null;
		}
	}
}
