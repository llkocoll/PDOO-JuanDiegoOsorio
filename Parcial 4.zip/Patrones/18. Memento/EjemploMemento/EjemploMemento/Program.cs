﻿using System;

namespace EjemploMemento
{
	class MainClass
	{
		
		static void Main()
		{
			Book book = new Book();
			book.ISBN = "0450488357";
			book.Title = "The Hunger Games";
			book.Author = "Suzanne Collins";
			book.ShowBook();
			System.Threading.Thread.Sleep(2000);


			Caretaker history = new Caretaker();
			history.Memento = book.CreateUndo();


			book.ISBN = "0330376144";
			book.Title = "The Da Vinci Code";
			book.Author = "Dan Brown";
			book.ShowBook();


			book.RestoreFromUndo(history.Memento);
			book.ShowBook();
		}
	}


	public class Book
	{
		private string _isbn;
		private string _title;
		private string _author;
		private DateTime _lastEdited;

		public string ISBN
		{
			get { return _isbn; }
			set
			{
				_isbn = value;
				SetLastEdited();
			}
		}

		public string Title
		{
			get { return _title; }
			set
			{
				_title = value;
				SetLastEdited();
			}
		}

		public string Author
		{
			get { return _author; }
			set
			{
				_author = value;
				SetLastEdited();
			}
		}

		public Book()
		{
			SetLastEdited();
		}

		private void SetLastEdited()
		{
			_lastEdited = DateTime.UtcNow;
		}

		public Memento CreateUndo()
		{
			return new Memento(_isbn, _title, _author, _lastEdited);
		}

		public void RestoreFromUndo(Memento memento)
		{
			_title = memento.Title;
			_author = memento.Author;
			_isbn = memento.ISBN;
			_lastEdited = memento.LastEdited;
		}

		public void ShowBook()
		{
			Console.WriteLine(
				"{0} - '{1}' by {2}, edited {3}.", ISBN, Title, Author, _lastEdited); 
		}
	}


	public class Memento
	{
		public string ISBN { get; private set; }
		public string Title { get; private set; }
		public string Author { get; private set; }
		public DateTime LastEdited { get; private set; }

		public Memento(string isbn, string title, string author, DateTime lastEdited)
		{
			ISBN = isbn;
			Title = title;
			Author = author;
			LastEdited = lastEdited;
		}
	}


	public class Caretaker
	{
		public Memento Memento { get; set; }
	}
}
