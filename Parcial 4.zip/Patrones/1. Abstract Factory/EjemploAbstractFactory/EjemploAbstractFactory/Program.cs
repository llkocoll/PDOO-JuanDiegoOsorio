﻿using System;

namespace EjemploAbstractFactory
{
	
	class MainClass
	{
		
		public static void Main()
		{
			
			GameEnterpriseFactory Sony = new SonyFactory();
			GameWorld world = new GameWorld(Sony);
			world.GameRelation();


			GameEnterpriseFactory Nintendo = new NintendoFactory();
			world = new GameWorld(Nintendo);
			world.GameRelation();


			Console.ReadKey();
		}
	}



	abstract class GameEnterpriseFactory
	{
		public abstract Genre CreateGenre();
		public abstract Game CreateGame();
	}


	class SonyFactory : GameEnterpriseFactory
	{
		public override Genre CreateGenre()
		{
			return new Shooter();
		}
		public override Game CreateGame()
		{
			return new Battlefield();
		}
	}


	class NintendoFactory : GameEnterpriseFactory
	{
		public override Genre CreateGenre()
		{
			return new Platform();
		}
		public override Game CreateGame()
		{
			return new Mario();
		}
	}


	abstract class Genre
	{
	}


	abstract class Game
	{
		public abstract void Belong(Genre h);
	}


	class Shooter : Genre
	{
	}


	class Battlefield : Game
	{
		public override void Belong(Genre h)
		{
			
			Console.WriteLine(this.GetType().Name +
				" belongs to the genre of " + h.GetType().Name);
		}
	}


	class Platform : Genre
	{
	}


	class Mario : Game
	{
		public override void Belong(Genre h)
		{
			
			Console.WriteLine(this.GetType().Name +
				" belongs to the genre " + h.GetType().Name);
		}
	}


	class GameWorld
	{
		private Genre _genre;
		private Game _game;


		public GameWorld(GameEnterpriseFactory factory)
		{
			_game = factory.CreateGame();
			_genre = factory.CreateGenre();
		}

		public void GameRelation()
		{
			_game.Belong(_genre);
		}
	}
}
